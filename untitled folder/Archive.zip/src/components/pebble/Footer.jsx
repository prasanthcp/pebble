import './Footer.css';
export default function Footer() {
    return (<footer> 
    <div className="container">Pebble by Pebble, build A mountain ⛰️ @Copyright 2026 </div>
    </footer>)
}