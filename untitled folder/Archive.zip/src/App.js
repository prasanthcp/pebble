import './App.css';
import PebbleApp from './components/pebble/PebbleApp';

function App() {
  
  return (
    <div className="App">
      <PebbleApp/>
    </div>
  );
}

export default App;